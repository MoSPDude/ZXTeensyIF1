sjasmplus main.asm -DMB03 -DZXSCR --lst=main.lst -DV=16
